const scanner = require('sonarqube-scanner');

scanner(
    {
        serverUrl: 'http://localhost:9000',
        token: "a06f4a531ac24fedd5df968d1b705fec0b576125",
        options: {
            'sonar.projectName': 'VILLELAVAL',
            'sonar.projectDescription': 'Here I can add a description of my project',
            'sonar.projectKey': 'VILLELAVAL',
            'sonar.projectVersion': '0.0.1',
            'sonar.exclusions': 'sonarqube/*,src/LavalBtn.test.js,config/CSSStub.js,src/index.js',
            'sonar.sourceEncoding': 'UTF-8',
        }
    },
    () => process.exit()
)