import React,{ Component } from 'react'  
import { connect } from 'react-redux' 
import Button from 'react-bootstrap/Button';
import {setBtnState} from '../redux/userActions'
import {getBtnState} from '../redux/selectors'
import Modal from 'react-bootstrap/Modal';

class LavalBtn extends Component{

    changeBtnState=()=>{
        this.props.setBtnState(!this.props.isClicked);
    }

    render(){
        return (
            <>
                <Button variant="primary" onClick={this.changeBtnState} hidden={this.props.isClicked}>Afficher Modal</Button>
                <Modal show={this.props.isClicked} onHide={this.changeBtnState}>
                    <Modal.Header closeButton>                
                    </Modal.Header>
                    <Modal.Body>Bonjour Laval</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.changeBtnState}>Close</Button>                
                    </Modal.Footer>
                </Modal>
            </>
        )
    }
}

const mapStateToProps = state => {  
    return {  
        isClicked: getBtnState(state)
    }  
  }  
    
  const mapDispatchToProps = dispatch => {  
    return {  
        setBtnState: (isClicked) => dispatch(setBtnState(isClicked))  
    }  
  }  
    
  export default connect(  
    mapStateToProps,  
    mapDispatchToProps  
  )(LavalBtn)