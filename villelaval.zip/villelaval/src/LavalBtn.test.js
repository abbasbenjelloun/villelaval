import React from 'react';
import App from './App';
import userReducer from './redux/userReducer';
import { cleanup, fireEvent, render, screen, waitForElementToBeRemoved  } from '@testing-library/react';
import toBeInTheDocument from '@testing-library/jest-dom';

describe('application reducers', () => {
  it('should return the initial state', () => {
    expect(userReducer()).toEqual((
      {"isClicked": false}));
    });
});


test('renders learn react link', async  () => {
  const buttonText="Afficher Modal";
  const modalText = "Bonjour Laval";
  render(<App />);  

  /*affichage du button 'Afficher Modal'*/
  let buttonElement = screen.queryByText(buttonText);
  let modalElement = screen.queryByText(modalText);
  expect(buttonElement).toBeInTheDocument();
  expect(modalElement).not.toBeInTheDocument();  
  
  /*clic sur le bouton 'Afficher Modal'*/
  fireEvent.click(buttonElement);
  buttonElement = screen.queryByText(buttonText);
  modalElement = screen.queryByText(modalText);
  expect(buttonElement).not.toBeVisible();
  //Affichage du modal
  expect(modalElement).toBeInTheDocument();
  expect(modalElement).toBeVisible();  

  /*fermer le modal*/
  let closeButton =  modalElement.nextSibling.lastChild;
  expect(closeButton).toHaveTextContent('Close')
  fireEvent.click(closeButton);
  await  waitForElementToBeRemoved(closeButton);
  buttonElement = screen.queryByText(buttonText);
  modalElement = screen.queryByText(modalText);
  expect(modalElement).not.toBeInTheDocument();
  //Réaffichage du bouton Afficher Modal
  expect(buttonElement).toBeVisible();

  cleanup();
});
