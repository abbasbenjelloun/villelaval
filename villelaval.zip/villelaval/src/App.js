import React, { Component } from 'react';
import './App.css';
import { Provider } from 'react-redux'
import LavalBtn  from './containers/LavalBtn';
import store from './redux/store'

class App extends Component {  
  render() {
    return (
      <div className="App">
        <Provider store={store}>
          <LavalBtn />
        </Provider>
      </div>
    );
  }
}

export default App;