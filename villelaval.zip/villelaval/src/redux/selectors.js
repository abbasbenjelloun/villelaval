import { createSelector } from 'reselect';

const getUserState = (state) => state.user;

export const getBtnState = createSelector(
    [getUserState],
    (state) => {
        return state.isClicked
    }
) 