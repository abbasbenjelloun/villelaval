import {  
    CHANGE_STATE
  } from './actions'  
    
  const initialState = {  
    isClicked: false
  }  
    
  const userReducer = (state = initialState, action = {}) => {
    
     if(action !== {} && action.type !==undefined && action.type===CHANGE_STATE ){
      return {  
        ...state,  
        isClicked: action.payload
      }
    }
    else{
      return state;
    }
  }  
    
  export default userReducer 