import { 
    CHANGE_STATE
  } from './actions'  

  export const setBtnState = (isClicked ) => {
    return (dispatch) => {
      dispatch({
        type:CHANGE_STATE,
        payload: isClicked
      });
    }
  }